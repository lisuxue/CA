let f x= 1 + x in (f 4)* 2
